package no.uio.inf5750.springjdbc.dao;

import java.util.Collection;

import no.uio.inf5750.springjdbc.model.Product;

public interface ProductDao
{
    int save( Product product );
    
    Collection<Product> getAll();
    
    void deleteAll();
}
