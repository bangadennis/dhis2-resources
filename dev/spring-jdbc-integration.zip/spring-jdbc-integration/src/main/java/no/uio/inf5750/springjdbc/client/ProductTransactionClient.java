package no.uio.inf5750.springjdbc.client;

import no.uio.inf5750.springjdbc.model.Product;
import no.uio.inf5750.springjdbc.service.ProductService;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class ProductTransactionClient
{
    /**
     * Running this example requires a PostgreSQL database called "inf5750" and
     * a login role called "inf5750" with password "inf5750". Execute the sql script
     * in /div/database.sql to create the database.
     * 
     * The save method will fail on the Product with the null name since the name
     * column is not null. The two first save operations will be rolled back due
     * to Spring transaction management. Try commenting out the Transactional
     * annotation in DefaultProductService to see the difference. 
     */
    public static void main( String[] args )
    {
        ApplicationContext context = new ClassPathXmlApplicationContext( "META-INF/beans.xml" );
        
        ProductService productService = (ProductService) context.getBean( "productService" );
        
        productService.deleteAll();        

        productService.save( new Product( "Cellphone", "Blue" ), new Product( "TV", "Black" ), new Product( null, "Grey" ) );        
    }
}
