package no.uio.inf5750.springjdbc.service;

import java.util.Collection;

import org.springframework.transaction.annotation.Transactional;

import no.uio.inf5750.springjdbc.dao.ProductDao;
import no.uio.inf5750.springjdbc.model.Product;

@Transactional
public class DefaultProductService
    implements ProductService
{
    private ProductDao productDao;
    
    public void setProductDao( ProductDao productDao )
    {
        this.productDao = productDao;
    }

    public int save( Product product )
    {
        return productDao.save( product );
    }
    
    public Collection<Product> getAll()
    {
        return productDao.getAll();
    }
    
    public void deleteAll()
    {
        productDao.deleteAll();
    }
    
    public void save( Product... products )
    {
        for ( Product product : products )
        {
            productDao.save( product );
        }
    }
}
