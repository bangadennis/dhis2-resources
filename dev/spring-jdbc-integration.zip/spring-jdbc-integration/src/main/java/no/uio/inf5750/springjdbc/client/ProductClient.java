package no.uio.inf5750.springjdbc.client;

import java.util.Collection;

import no.uio.inf5750.springjdbc.dao.ProductDao;
import no.uio.inf5750.springjdbc.model.Product;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class ProductClient
{
    /**
     * Running this example requires a PostgreSQL database called "inf5750" and
     * a login role called "inf5750" with password "inf5750". Execute the sql script
     * in /div/database.sql to create the database.
     */
    public static void main( String[] args )
    {
        ApplicationContext context = new ClassPathXmlApplicationContext( "META-INF/beans.xml" );
        
        ProductDao productDao = (ProductDao) context.getBean( "productDao" );

        productDao.deleteAll();
        
        Product productA = new Product( "Cellphone", "Blue" );
        Product productB = new Product( "TV", "Black" );
        
        productDao.save( productA );
        productDao.save( productB );

        Collection<Product> products = productDao.getAll();
        
        System.out.println( "All:\t" + products );
    }
}
