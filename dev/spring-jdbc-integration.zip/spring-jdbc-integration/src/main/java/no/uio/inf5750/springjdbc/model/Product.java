package no.uio.inf5750.springjdbc.model;

public class Product
{
    private int id;
    
    private String name;
    
    private String color;
    
    public Product()
    {   
    }

    public Product( String name, String color )
    {   
        this.name = name;
        this.color = color;
    }
    
    @Override
    public String toString()
    {
        return "[" + name + ", " + color + "]";
    }    

    public int getId()
    {
        return id;
    }

    public void setId( int id )
    {
        this.id = id;
    }

    public String getName()
    {
        return name;
    }

    public void setName( String name )
    {
        this.name = name;
    }

    public String getColor()
    {
        return color;
    }

    public void setColor( String color )
    {
        this.color = color;
    }
}
