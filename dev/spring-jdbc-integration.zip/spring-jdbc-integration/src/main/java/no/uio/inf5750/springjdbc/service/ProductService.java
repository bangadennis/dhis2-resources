package no.uio.inf5750.springjdbc.service;

import java.util.Collection;

import no.uio.inf5750.springjdbc.model.Product;

public interface ProductService
{
    int save( Product product );
    
    Collection<Product> getAll();
    
    void deleteAll();
    
    void save( Product... products );
}
