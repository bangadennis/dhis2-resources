package no.uio.inf5750.springjdbc.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;

import no.uio.inf5750.springjdbc.model.Product;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

public class JdbcProductDao
    implements ProductDao
{
    private JdbcTemplate template;
    
    public void setTemplate( JdbcTemplate template )
    {
        this.template = template;
    }

    public int save( Product product )
    {
        String sql = "insert into product ( id, name, color ) values ( nextval('inf5750_sequence'), ?, ? )";
        
        return template.update( sql, new Object[] { product.getName(), product.getColor() } );
    }

    public Collection<Product> getAll()
    {
        String sql = "select * from product";
        
        return template.query( sql, new ProductMapper() );
    }
    
    public void deleteAll()
    {
        String sql = "delete from product";
        
        template.update( sql );
    }

    private static final class ProductMapper
        implements RowMapper<Product>
    {
        public Product mapRow( ResultSet resultSet, int rowNumber )
            throws SQLException
        {
            Product product = new Product();
            
            product.setId( resultSet.getInt( "id" ) );
            product.setName( resultSet.getString( "name" ) );
            product.setColor( resultSet.getString( "color" ) );
            
            return product;
        }        
    }
}
