package no.uio.inf5750.example.spring.i18n;

import java.util.Locale;

import org.springframework.context.MessageSource;

public class DefaultSaluteService
    implements SaluteService
{
    private MessageSource messages;

    public void setMessages( MessageSource messages )
    {
        this.messages = messages;
    }
    
    private Locale locale;
        
    public void setLocale( Locale locale )
    {
        this.locale = locale;
    }

    public String salute()
    {
        return messages.getMessage( "salute", null, locale );
    }
}
