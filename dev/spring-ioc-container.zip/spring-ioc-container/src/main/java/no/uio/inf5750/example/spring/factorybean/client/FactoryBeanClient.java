package no.uio.inf5750.example.spring.factorybean.client;

import no.uio.inf5750.example.spring.factorybean.DatabaseConfig;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class FactoryBeanClient
{
    public static void main( String[] args )
    {
        ApplicationContext context = new ClassPathXmlApplicationContext( "META-INF/beans.xml" );
        
        DatabaseConfig config = (DatabaseConfig) context.getBean( "databaseConfig" ); // Returns the factory object - not the bean
        
        System.out.println( config );
    }
}
