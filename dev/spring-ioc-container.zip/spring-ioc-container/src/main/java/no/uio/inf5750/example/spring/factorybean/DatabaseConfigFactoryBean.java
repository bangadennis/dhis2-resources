package no.uio.inf5750.example.spring.factorybean;

import java.util.Properties;

import org.springframework.beans.factory.FactoryBean;
import org.springframework.core.io.ClassPathResource;

public class DatabaseConfigFactoryBean
    implements FactoryBean<DatabaseConfig>
{
    @Override
    public DatabaseConfig getObject()
        throws Exception
    {
        Properties properties = new Properties();        
        properties.load( new ClassPathResource( "connection.properties" ).getInputStream() );
        
        DatabaseConfig config = new DatabaseConfig();
        config.setDriverClass( properties.getProperty( "connection.driver_class" ) );
        config.setUrl( properties.getProperty( "connection.url" ) );
        config.setUsername( properties.getProperty( "connection.username" ) );
        config.setPassword( properties.getProperty( "connection.password" ) );
        
        return config;
    }

    @Override
    public Class<?> getObjectType()
    {
        return DatabaseConfig.class;
    }

    @Override
    public boolean isSingleton()
    {
        return true;
    }
}
