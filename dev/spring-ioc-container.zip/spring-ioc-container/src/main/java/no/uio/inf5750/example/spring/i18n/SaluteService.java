package no.uio.inf5750.example.spring.i18n;

import java.util.Locale;

public interface SaluteService
{
    String salute();
    
    void setLocale( Locale locale );
}
