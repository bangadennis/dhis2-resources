package no.uio.inf5750.example.spring.lifecycle.client;

import java.util.Properties;

import no.uio.inf5750.example.spring.lifecycle.ConfigurationProvider;

import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;

public class LifecycleBeanClient
{
    public static void main( String[] args )
    {
        // Starts up Spring
        
        ConfigurableBeanFactory beanFactory = new XmlBeanFactory( new ClassPathResource( "META-INF/beans.xml" ) );
        
        // Retrieves bean instance, no methods invoked on the bean
        
        ConfigurationProvider configurationProvider = (ConfigurationProvider) beanFactory.getBean( "configurationProvider" );
        
        Properties configuration = configurationProvider.getConfiguration();
        
        System.out.println( "Configuration: " + configuration.toString() );
        
        // Destroys bean instance, no methods invoked on the bean
        
        beanFactory.destroyBean( "configurationProvider", configurationProvider );
    }
}
