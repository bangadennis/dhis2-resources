package no.uio.inf5750.example.spring.scopes.client;

import no.uio.inf5750.example.spring.scopes.ScopedBean;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class ScopedBeanClient
{
    public static void main( String[] args )
    {
        final String beanId = "singletonScopedBean";        
        //final String beanId = "prototypeScopedBean";
        
        // Starts up Spring
        
        ApplicationContext context = new ClassPathXmlApplicationContext( "META-INF/beans.xml" );
        
        // Gets a bean instance from Spring
        
        ScopedBean beanA = (ScopedBean) context.getBean( beanId );
        
        // Give the bean state by setting a property on it
        
        beanA.setState( "This bean is in a good mood" );
        
        // Gets another bean instance from Spring
        
        ScopedBean beanB = (ScopedBean) context.getBean( beanId );
        
        // Checks whether beanA is the same instance as beanB or not
        
        System.out.println( beanB.getState() );
    }
}
