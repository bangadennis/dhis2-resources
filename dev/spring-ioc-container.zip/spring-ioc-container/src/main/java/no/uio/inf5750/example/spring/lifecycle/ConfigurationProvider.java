package no.uio.inf5750.example.spring.lifecycle;

import java.util.Properties;

public interface ConfigurationProvider
{    
    Properties getConfiguration();
}
