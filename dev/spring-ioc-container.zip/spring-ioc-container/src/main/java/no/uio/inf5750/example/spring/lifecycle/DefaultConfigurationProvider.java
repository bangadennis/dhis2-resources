package no.uio.inf5750.example.spring.lifecycle;

import java.util.Properties;

import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class DefaultConfigurationProvider
    implements ConfigurationProvider
{
    private Properties properties = new Properties();
    
    public void init()
        throws Exception
    {
        Resource resource = new ClassPathResource( "connection.properties" );
        
        properties.load( resource.getInputStream() );
        
        System.out.println( "Loaded connection configuration" );
    }
    
    public Properties getConfiguration()
    {
        return properties;
    }
    
    public void destroy()
    {
        properties = new Properties();
        
        System.out.println( "Destroyed connection configuration" );
    }
}
