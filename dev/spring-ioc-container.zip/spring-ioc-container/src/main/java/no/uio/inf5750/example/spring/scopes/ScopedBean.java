package no.uio.inf5750.example.spring.scopes;

public interface ScopedBean
{
    void setState( String state );
    
    String getState();
}
