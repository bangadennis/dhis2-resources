package no.uio.inf5750.example.spring.scopes;

public class PrototypeScopedBean
    implements ScopedBean
{
    private String state;

    public String getState()
    {
        return state;
    }

    public void setState( String state )
    {
        this.state = state;
    }
}
