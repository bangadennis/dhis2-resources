package no.uio.inf5750.example.spring.resource;

import java.net.MalformedURLException;
import java.util.Properties;

import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;

public class ResourceLoaderTest
{
    public static void main( String args[] )
        throws Exception
    {
        loadFromClassPath();
        loadFromFileSystem();
        loadFromUrl();
    }
    
    public static void loadFromClassPath()
    {
        Resource resource = new ClassPathResource( "connection.properties" );
        
        printResource( resource );        
    }
    
    public static void loadFromFileSystem()
    {
        Resource resource = new FileSystemResource( "src/main/resources/connection.properties" );
        
        printResource( resource );
    }

    public static void loadFromUrl() // Requires internet connection
        throws MalformedURLException
    {
        Resource resource = new UrlResource( "http://folk.uio.no/larshelg/files/connection.properties" );
        
        printResource( resource );
    }
    
    private static void printResource( Resource resource )
    {
        try
        {
            Properties properties = new Properties();
            
            properties.load( resource.getInputStream() );
            
            System.out.println( "Loading " + resource.getDescription() );
            System.out.println( properties.toString() );
            System.out.println();
        }
        catch ( Exception ex )
        {
            throw new RuntimeException( ex );
        }
    }
}
