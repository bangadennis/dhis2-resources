package no.uio.inf5750.example.spring.i18n.client;

import java.util.Locale;

import no.uio.inf5750.example.spring.i18n.SaluteService;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

@SuppressWarnings( "unused" )
public class I18nClient
{
    private static final Locale FRENCH = Locale.FRANCE;
    private static final Locale GERMAN = Locale.GERMANY;
    private static final Locale ENGLISH = Locale.UK;
    private static final Locale SPANISH = new Locale( "es", "ES" );
    
    public static void main( String[] args )
    {
        // Starts up Spring
        
        ApplicationContext context = new ClassPathXmlApplicationContext( "META-INF/beans.xml" );
        
        SaluteService saluteService = (SaluteService) context.getBean( "saluteService" );
        
        saluteService.setLocale( SPANISH );
        
        System.out.println( saluteService.salute() );        
    }
}
