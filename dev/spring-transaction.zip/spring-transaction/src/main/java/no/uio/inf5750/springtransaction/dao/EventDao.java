package no.uio.inf5750.springtransaction.dao;

import no.uio.inf5750.springtransaction.model.Event;

public interface EventDao
{
    Integer saveEvent( Event event );
    
    Event getEvent( Integer id );
    
    void deleteEvent( Event event );
}
