package no.uio.inf5750.springtransaction.client;

import java.util.Date;

import no.uio.inf5750.springtransaction.dao.EventDao;
import no.uio.inf5750.springtransaction.model.Event;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class EventClient
{
    public static void main( String[] args )
    {
        ApplicationContext context = new ClassPathXmlApplicationContext( "META-INF/beans.xml" );
        
        EventDao eventDao = (EventDao) context.getBean( "eventDao" );
        
        Event event = new Event( "U2 concert", new Date() );
        
        int id = eventDao.saveEvent( event );
        
        eventDao.getEvent( id );        
    }
}
