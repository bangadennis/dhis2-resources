package no.uio.inf5750.springtransaction.dao;

import java.util.Date;

import no.uio.inf5750.springtransaction.model.Event;

public class DummyEventDao
    implements EventDao
{
    public Integer saveEvent( Event event )
    {
        System.out.println( "Saving event..." );
        
        return 1;
    }
    
    public Event getEvent( Integer id )
    {
        System.out.println( "Getting event..." );
        
        return new Event( "", new Date() );
    }
    
    public void deleteEvent( Event event )
    {
        System.out.println( "Deleting event" );
    }
}
