package no.uio.inf5750.springtransaction.model;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Event
{
    private int id;
    
    private String title;
    
    private Date date;
    
    public Event()
    {
    }
    
    public Event( String title, Date date )
    {
        this.title = title;
        this.date = date;
    }
    
    public int getId()
    {
        return id;
    }

    public void setId( int id )
    {
        this.id = id;
    }

    public String getTitle()
    {
        return title;
    }

    public void setTitle( String title )
    {
        this.title = title;
    }
    
    public Date getDate()
    {
        return date;
    }

    public void setDate( Date date )
    {
        this.date = date;
    }

    @Override
    public int hashCode()
    {
        final int PRIME = 31;
                
        int result = 1;
        
        result = PRIME * result + ( ( title == null ) ? 0 : title.hashCode() );
        
        return result;
    }

    @Override
    public boolean equals( Object obj )
    {
        if ( this == obj )
        {
            return true;
        }
        
        if ( obj == null )
        {
            return false;
        }
        
        if ( getClass() != obj.getClass() )
        {
            return false;
        }
        
        final Event other = (Event) obj;
        
        if ( title == null )
        {
            if ( other.title != null )
            {
                return false;
            }
        }
        
        else if ( !title.equals( other.title ) )
        {
            return false;
        }
        
        return true;
    }
    
    @Override
    public String toString()
    {
        return title + " " + new SimpleDateFormat( "dd.mm.yyyy" ).format( date );
    }
}
