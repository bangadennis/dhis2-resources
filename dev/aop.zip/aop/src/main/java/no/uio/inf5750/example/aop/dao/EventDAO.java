package no.uio.inf5750.example.aop.dao;

import java.util.Collection;

import no.uio.inf5750.example.aop.model.Event;

public interface EventDAO
{
    Integer saveEvent( Event event );
    
    Event getEvent( Integer id );
    
    Collection<Event> getAllEvents();
    
    void deleteEvent( Event event );
}
