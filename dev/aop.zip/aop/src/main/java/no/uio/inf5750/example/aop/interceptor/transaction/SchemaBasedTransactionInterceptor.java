package no.uio.inf5750.example.aop.interceptor.transaction;

import org.aspectj.lang.ProceedingJoinPoint;

import no.uio.inf5750.example.aop.transaction.TransactionManager;

public class SchemaBasedTransactionInterceptor
{
    private TransactionManager transactionManager;
    
    public void setTransactionManager( TransactionManager transactionManager )
    {
        this.transactionManager = transactionManager;
    }
    
    public void intercept( ProceedingJoinPoint joinPoint )
        throws Throwable
    {
        transactionManager.enter();
        
        try
        {
            joinPoint.proceed();
        }
        catch ( Throwable t )
        {
            transactionManager.abort();
            
            throw t;
        }
        
        transactionManager.leave();
    }
}
