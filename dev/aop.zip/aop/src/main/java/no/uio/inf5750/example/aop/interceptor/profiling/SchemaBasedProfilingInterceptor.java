package no.uio.inf5750.example.aop.interceptor.profiling;

import no.uio.inf5750.example.aop.clock.StopWatch;

import org.aspectj.lang.ProceedingJoinPoint;

public class SchemaBasedProfilingInterceptor
{
    public void intercept( ProceedingJoinPoint joinPoint )
        throws Throwable
    {
        StopWatch clock = new StopWatch( joinPoint.getSignature().toShortString() );
        
        try
        {
            clock.start();
            
            joinPoint.proceed();
        }
        finally
        {
            clock.stop();
            
            System.out.println( clock.prettyPrint() );
        }        
    }
}
