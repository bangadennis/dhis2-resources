package no.uio.inf5750.example.aop.interceptor.logging;

import no.uio.inf5750.example.aop.log.Log;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;

@Aspect
public class AnnotatedLoggingInterceptor
{
    @Pointcut( "execution( * no.uio.inf5750.example.aop.dao.*.*(..) )" )
    public void daoLayer() {}
    
    @Before( "no.uio.inf5750.example.aop.interceptor.logging.AnnotatedLoggingInterceptor.daoLayer() and " + 
             "args( object, .. )" )
    public void intercept( JoinPoint joinPoint, Object object )
    {
        String arg = object != null ? " with argument " + object.toString() : " with no arguments";
        
        Log.info( "Invoking method " + joinPoint.getSignature().toShortString() + arg );
    }
}
