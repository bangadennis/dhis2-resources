package no.uio.inf5750.example.aop.log;

import java.util.Calendar;

public class Log
{
    private static Calendar calendar = Calendar.getInstance();
    
    public static void info( String message )
    {
        System.out.println( "[INFO] " + calendar.getTime().toString() + ": " + message );
    }
}
