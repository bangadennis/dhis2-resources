package no.uio.inf5750.example.aop.interceptor.logging;

import no.uio.inf5750.example.aop.log.Log;

import org.aspectj.lang.JoinPoint;

public class SchemaBasedLoggingInterceptor
{
    public void intercept( JoinPoint joinPoint, Object object )
    {
        String returnValue = object != null ? " with return value " + object : " with no return value";
        
        Log.info( "Invoked method " + joinPoint.getSignature().toShortString() + returnValue );
    }
}
