package no.uio.inf5750.example.aop.transaction;

public interface TransactionManager
{
    public void enter();
    
    public void leave();
    
    public void abort();
}
