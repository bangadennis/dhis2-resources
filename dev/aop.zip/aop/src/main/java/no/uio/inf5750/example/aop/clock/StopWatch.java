package no.uio.inf5750.example.aop.clock;

public class StopWatch
{
    private String currentMethod;
    
    private long time;
    
    public StopWatch( String currentMethod )
    {
        this.currentMethod = currentMethod;
        
        time = 0;        
    }
    
    public void start()
    {
        time = System.nanoTime();
    }
    
    public void stop()
    {
        time = System.nanoTime() - time;        
    }
    
    public String prettyPrint()
    {
        return "Executed " + currentMethod + " in " + ( time / 1000 ) + " micro-seconds";        
    }
}
