package no.uio.inf5750.example.aop.client;

import java.util.Date;

import no.uio.inf5750.example.aop.dao.EventDAO;
import no.uio.inf5750.example.aop.model.Event;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

@SuppressWarnings( "unused" )
public class EventManagerClient
{
    // Path to various Spring configuration files - use as param to ApplicationContext to test
    
    private static String transactionAnnotatedConfigFilePath = "META-INF/transaction/beans-annotated.xml";
    private static String transactionSchemaBasedConfigFilePath = "META-INF/transaction/beans-schemabased.xml";
    
    private static String loggingAnnotatedConfigFilePath = "META-INF/logging/beans-annotated.xml";
    private static String loggingSchemaBasedConfigFilePath = "META-INF/logging/beans-schemabased.xml";

    private static String profilingAnnotatedConfigFilePath = "META-INF/profiling/beans-annotated.xml";
    private static String profilingSchemaBasedConfigFilePath = "META-INF/profiling/beans-schemabased.xml";
    
    public static void main( String[] args )
    {
        // Starting Spring and retrieving EventDAO bean        
        
        ApplicationContext context = new ClassPathXmlApplicationContext( transactionAnnotatedConfigFilePath );
                
        EventDAO eventDAO = (EventDAO) context.getBean( "eventDAO" );
        
        // Performing operations on the eventDAO
        
        Event event = new Event( "U2 concert", new Date() );
        
        Integer id = eventDAO.saveEvent( event );
        
        event = eventDAO.getEvent( id );
        
        eventDAO.getAllEvents();
    }
}
