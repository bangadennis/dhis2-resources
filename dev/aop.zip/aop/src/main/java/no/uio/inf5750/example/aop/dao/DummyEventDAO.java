package no.uio.inf5750.example.aop.dao;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;

import no.uio.inf5750.example.aop.model.Event;

public class DummyEventDAO
    implements EventDAO
{
    public Integer saveEvent( Event event )
    {
        System.out.println( "Saving event..." );
        
        return 1;
    }
    
    public Event getEvent( Integer id )
    {
        System.out.println( "Getting event..." );
        
        return new Event( "U2 concert", new Date() );
    }
    
    public Collection<Event> getAllEvents()
    {
        List<Event> events = new ArrayList<Event>();
        events.add( new Event( "U2 concert", new Date() ) );
        return events;
    }
    
    public void deleteEvent( Event event )
    {
        System.out.println( "Deleting event" );
    }
}
