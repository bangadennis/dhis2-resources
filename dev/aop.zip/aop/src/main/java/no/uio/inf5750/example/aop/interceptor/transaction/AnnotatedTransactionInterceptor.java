package no.uio.inf5750.example.aop.interceptor.transaction;

import no.uio.inf5750.example.aop.transaction.TransactionManager;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;

@Aspect
public class AnnotatedTransactionInterceptor
{
    private TransactionManager transactionManager;
    
    public void setTransactionManager( TransactionManager transactionManager )
    {
        this.transactionManager = transactionManager;
    }

    @Around( "execution( * no.uio.inf5750.example.aop.dao.*.*(..) )" )
    public void intercept( ProceedingJoinPoint joinPoint )
        throws Throwable
    {
        transactionManager.enter();
        
        try
        {
            joinPoint.proceed();
        }
        catch ( Throwable t )
        {
            transactionManager.abort();
            
            throw t;
        }
        
        transactionManager.leave();
    }
}
