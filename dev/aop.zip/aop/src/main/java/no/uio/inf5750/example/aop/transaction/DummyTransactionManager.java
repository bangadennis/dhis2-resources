package no.uio.inf5750.example.aop.transaction;

public class DummyTransactionManager
    implements TransactionManager
{
    public void enter()
    {
        System.out.println( "Entering transaction" );
    }
    
    public void leave()
    {
        System.out.println( "Leaving transaction" );
    }
    
    public void abort()
    {
        System.out.println( "Aborting transaction" );
    }
}
