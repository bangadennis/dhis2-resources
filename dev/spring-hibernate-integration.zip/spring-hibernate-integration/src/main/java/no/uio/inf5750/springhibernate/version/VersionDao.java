package no.uio.inf5750.springhibernate.version;

import no.uio.inf5750.springhibernate.dao.GenericDao;
import no.uio.inf5750.springhibernate.model.Version;

public interface VersionDao
    extends GenericDao<Version>
{
    Version getByName( String name );
}
