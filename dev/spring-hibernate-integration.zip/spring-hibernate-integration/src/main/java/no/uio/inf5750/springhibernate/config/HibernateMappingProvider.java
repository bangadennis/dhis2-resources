package no.uio.inf5750.springhibernate.config;

import org.springframework.beans.factory.FactoryBean;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class HibernateMappingProvider
    implements FactoryBean
{
    // -------------------------------------------------------------------------
    // FactoryBean implementation
    // -------------------------------------------------------------------------

    public Object getObject()
        throws Exception
    {
        Resource[] locations = { new ClassPathResource( "hibernate" ) };
        
        return locations;
    }

    public Class<?> getObjectType()
    {
        return Resource.class;
    }

    public boolean isSingleton()
    {
        return true;
    }
}
