package no.uio.inf5750.springhibernate.product;

import java.util.Collection;

import no.uio.inf5750.springhibernate.dao.HibernateGenericDao;
import no.uio.inf5750.springhibernate.model.Product;

import org.hibernate.criterion.Restrictions;

public class HibernateProductDao
    extends HibernateGenericDao<Product> implements ProductDao
{
    public Product getByName( String name )
    {
        return getObject( Restrictions.eq( "name", name ) );
    }
    
    public Collection<Product> getByColor( String color )
    {
        return getList( Restrictions.eq( "color", color ) );
    }
}
