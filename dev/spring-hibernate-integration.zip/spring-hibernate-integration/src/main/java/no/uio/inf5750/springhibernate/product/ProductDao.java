package no.uio.inf5750.springhibernate.product;

import java.util.Collection;

import no.uio.inf5750.springhibernate.dao.GenericDao;
import no.uio.inf5750.springhibernate.model.Product;

public interface ProductDao
    extends GenericDao<Product>
{
    Product getByName( String name );
    
    Collection<Product> getByColor( String color );
}
