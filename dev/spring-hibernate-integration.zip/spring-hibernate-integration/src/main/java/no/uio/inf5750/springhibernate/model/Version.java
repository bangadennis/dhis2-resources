package no.uio.inf5750.springhibernate.model;

public class Version
{
    private int id;
    
    private String name;
    
    public Version()
    {   
    }
    
    public Version( String name )
    {
        this.name = name;
    }

    @Override
    public int hashCode()
    {
        return name.hashCode();
    }

    @Override
    public boolean equals( Object object )
    {
        if ( this == object )
        {
            return true;
        }
        if ( object == null )
        {
            return false;
        }
        if ( getClass() != object.getClass() )
        {
            return false;
        }
        
        final Version other = (Version) object;
        
        return name.equals( other.name );
    }
    
    public int getId()
    {
        return id;
    }

    public void setId( int id )
    {
        this.id = id;
    }

    public String getName()
    {
        return name;
    }

    public void setName( String name )
    {
        this.name = name;
    }
}
