package no.uio.inf5750.springhibernate.client;

import java.util.Collection;

import no.uio.inf5750.springhibernate.model.Product;
import no.uio.inf5750.springhibernate.model.Version;
import no.uio.inf5750.springhibernate.product.ProductDao;
import no.uio.inf5750.springhibernate.version.VersionDao;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class ProductClient
{
    public static void main( String[] args )
    {
        ApplicationContext context = new ClassPathXmlApplicationContext( "META-INF/beans.xml" );
        
        ProductDao productDao = (ProductDao) context.getBean( "productDao" );
        VersionDao versionDao = (VersionDao) context.getBean( "versionDao" );

        Version versionA = new Version( "1.3" );
        Version versionB = new Version( "1.4" );
        Version versionC = new Version( "2.0" );        
        
        Product productA = new Product( "Cellphone", "Blue" );
        Product productB = new Product( "TV", "Black" );
        Product productC = new Product( "Radio", "Black" );
        
        versionDao.save( versionA );
        versionDao.save( versionB );
        versionDao.save( versionC );
        
        int productIdA = productDao.save( productA );
        productDao.save( productB );
        productDao.save( productC );
        
        Collection<Product> products = productDao.getAll();
        
        System.out.println( "All:\t" + products );

        products = productDao.getByColor( "Black" );
        
        System.out.println( "Black:\t" + products );
        
        productDao.delete( productB );
        
        products = productDao.getAll();
        
        System.out.println( "All:\t" + products );
        
        productA = productDao.get( productIdA );
        
        System.out.println( "Prod A:\t" + productA );     
        
        productB = productDao.getByName( "TV" );
        
        System.out.println( "TV:\t" + productB );
    }
}
