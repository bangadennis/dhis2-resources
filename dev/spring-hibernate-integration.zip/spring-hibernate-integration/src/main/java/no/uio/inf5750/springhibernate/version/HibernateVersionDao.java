package no.uio.inf5750.springhibernate.version;

import no.uio.inf5750.springhibernate.dao.HibernateGenericDao;
import no.uio.inf5750.springhibernate.model.Version;

import org.hibernate.criterion.Restrictions;

public class HibernateVersionDao
    extends HibernateGenericDao<Version> implements VersionDao
{
    public Version getByName( String name )
    {
        return getObject( Restrictions.eq( "name", name ) );
    }
}
