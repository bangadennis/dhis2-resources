package no.uio.inf5750.springhibernate.model;

import java.util.HashSet;
import java.util.Set;

public class Product
{
    private int id;
    
    private String name;
    
    private String color;
    
    private Set<Version> versions = new HashSet<Version>();
    
    public Product()
    {   
    }

    public Product( String name, String color )
    {   
        this.name = name;
        this.color = color;
    }
    
    @Override
    public String toString()
    {
        return "[" + name + ", " + color + "]";
    }
    
    @Override
    public int hashCode()
    {
        return name.hashCode();
    }

    @Override
    public boolean equals( Object object )
    {
        if ( this == object )
        {
            return true;
        }
        
        if ( object == null )
        {
            return false;
        }
        
        if ( getClass() != object.getClass() )
        {
            return false;
        }
        
        final Product other = (Product) object;
        
        return name.equals( other.getName() );
    }

    public int getId()
    {
        return id;
    }

    public void setId( int id )
    {
        this.id = id;
    }

    public String getName()
    {
        return name;
    }

    public void setName( String name )
    {
        this.name = name;
    }

    public String getColor()
    {
        return color;
    }

    public void setColor( String color )
    {
        this.color = color;
    }

    public Set<Version> getVersions()
    {
        return versions;
    }

    public void setVersions( Set<Version> versions )
    {
        this.versions = versions;
    }
}
