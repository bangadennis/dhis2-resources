package no.uio.inf5750.example.model;

public class Student
{
    private String name;
    
    private String address;
    
    public Student()
    {   
    }
    
    @Override
    public String toString()
    {
        return "[" + name + ", " + address + "]";
    }
    
    @Override
    public boolean equals( Object object )
    {
        return object != null && object instanceof Student && name.equals( ((Student)object).getName() );
    }
    
    @Override
    public int hashCode()
    {
        return name.hashCode();
    }

    public String getName()
    {
        return name;
    }

    public void setName( String name )
    {
        this.name = name;
    }

    public String getAddress()
    {
        return address;
    }

    public void setAddress( String address )
    {
        this.address = address;
    }
}
