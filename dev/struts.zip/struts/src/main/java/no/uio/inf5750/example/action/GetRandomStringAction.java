package no.uio.inf5750.example.action;

import java.util.Random;

import com.opensymphony.xwork2.Action;

public class GetRandomStringAction
    implements Action
{
    private static final String LINEBREAK = "<br>";
    
    private String word;
    
    public String getWord()
    {
        return word;
    }
    
    private Integer numberOfChars = 16;
    
    public void setNumberOfChars( Integer numberOfChars )
    {
        this.numberOfChars = numberOfChars;
    }

    public String execute()
    {
        StringBuffer buffer = new StringBuffer();
        
        Random random = new Random();
        
        for ( int i = 0; i < numberOfChars; i++ )
        {
            for ( int j = 0; j < numberOfChars; j++ )
            {
                int n = random.nextInt( 26 ) + 65;
                
                buffer.append( (char) n );
            }
            
            buffer.append( LINEBREAK );
        }

        word = buffer.toString();
        
        return SUCCESS;
    }
}
