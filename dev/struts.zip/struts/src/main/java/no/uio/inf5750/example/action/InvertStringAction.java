package no.uio.inf5750.example.action;

import com.opensymphony.xwork2.Action;

public class InvertStringAction
    implements Action
{
    private String word;

    public void setWord( String word )
    {
        this.word = word;
    }
    
    private String invertedWord;
    
    public String getInvertedWord()
    {
        return invertedWord;
    }

    public String execute()
    {
        StringBuffer buffer = new StringBuffer();
        
        if ( word != null && word.trim().length() > 0 )
        {
            char[] chars = word.toCharArray();
            
            for ( int i = chars.length - 1; i >= 0; i-- )
            {
                buffer.append( chars[ i ] );
            }
            
            invertedWord = buffer.toString();
            
            return SUCCESS;
        }
        
        return INPUT;
    }
}
