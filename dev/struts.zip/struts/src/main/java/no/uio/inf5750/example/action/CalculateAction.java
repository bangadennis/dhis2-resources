package no.uio.inf5750.example.action;

import com.opensymphony.xwork2.ActionSupport;

public class CalculateAction
    extends ActionSupport
{
    private Integer numerator;

    public void setNumerator( Integer numerator )
    {
        this.numerator = numerator;
    }

    private Integer denominator;

    public void setDenominator( Integer denominator )
    {
        this.denominator = denominator;
    }

    private Double result;

    public Double getResult()
    {
        return result;
    }

    @Override
    public void validate()
    {
        if ( numerator == null )
        {
            addFieldError( "numerator", "Please enter a numerator" );
        }
        
        if ( denominator == null )
        {
            addFieldError( "denominator", "Please enter a denominator" );
        }
        
        if ( denominator != null && denominator == 0 )
        {
            addFieldError( "denominator", "Division by zero not allowed" );
        }
    }
    
    @Override
    public String execute()
    {
        result = Double.valueOf( String.valueOf( numerator ) ) / denominator;
        
        return SUCCESS;
    }
}
