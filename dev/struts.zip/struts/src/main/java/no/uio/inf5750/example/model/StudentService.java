package no.uio.inf5750.example.model;

import java.util.Collection;

public interface StudentService
{
    void saveStudent( Student student );
    
    void deleteStudent( Student student );
    
    Collection<Student> getAllStudents();
}
