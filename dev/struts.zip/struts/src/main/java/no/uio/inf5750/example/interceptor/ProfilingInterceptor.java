package no.uio.inf5750.example.interceptor;

import com.opensymphony.xwork2.ActionInvocation;
import com.opensymphony.xwork2.interceptor.Interceptor;

public class ProfilingInterceptor
    implements Interceptor
{
    public String intercept( ActionInvocation invocation )
        throws Exception
    {
        long startTime = System.nanoTime();
        
        String result = invocation.invoke();
        
        long executionTime = System.nanoTime() - startTime;
        
        System.out.println( "Execution took " + executionTime + " nano seconds" );
        
        return result;
    }
    
    public void init()
    {   
    }
    
    public void destroy()
    {   
    }
}
