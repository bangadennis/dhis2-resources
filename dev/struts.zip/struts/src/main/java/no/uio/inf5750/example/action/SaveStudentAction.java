package no.uio.inf5750.example.action;

import no.uio.inf5750.example.model.Student;
import no.uio.inf5750.example.model.StudentService;

import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

public class SaveStudentAction
    extends ActionSupport implements ModelDriven<Student>
{
    private Student student = new Student();
    
    public Student getModel()
    {
        return student;
    }
    
    private StudentService studentService;
    
    public void setStudentService( StudentService studentService )
    {
        this.studentService = studentService;
    }

    public String execute()
    {
        studentService.saveStudent( student );
        
        System.out.println( "Saving student: " + student );
        
        return SUCCESS;
    }
}
