package no.uio.inf5750.example.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class HelloWorldServlet
    extends HttpServlet
{
    @Override
    public void doGet( HttpServletRequest request, HttpServletResponse response )
        throws IOException
    {
        doHandle( request, response );
    }
    
    @Override
    public void doPost( HttpServletRequest request, HttpServletResponse response )
        throws IOException
    {
        doHandle( request, response );
    }
    
    @SuppressWarnings("unchecked")
    private void doHandle( HttpServletRequest request, HttpServletResponse response )
        throws IOException
    {
        PrintWriter writer = response.getWriter();
        writer.println( "<html><body>" );
        writer.println( "<h3>Hello World!</h3>" );
        writer.println( "<h4>Headers</h4>" );
        
        Enumeration<String> headers = request.getHeaderNames();
        
        while ( headers.hasMoreElements() )
        {
            String name = headers.nextElement();
            
            writer.println( "<p>" + name + ": " + request.getHeader( name ) + "</p>" );
        }
        
        writer.println( "<h4>Parameters</h4>" );
        
        Enumeration<String> params = request.getParameterNames();
        
        while ( params.hasMoreElements() )
        {
            String param = params.nextElement();
            
            writer.println( "<p>" + param + ": " + request.getParameter( param ) + "</p>" );
        }
        
        writer.println( "</body></html>" );
        writer.flush();
    }
}
