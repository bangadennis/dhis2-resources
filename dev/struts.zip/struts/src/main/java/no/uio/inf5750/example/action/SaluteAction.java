package no.uio.inf5750.example.action;

import com.opensymphony.xwork2.ActionSupport;

public class SaluteAction
    extends ActionSupport
{
    public String execute()
    {        
        System.out.println( "Salute: " + getText( "salute" ) );
        
        System.out.println( "Locale" + getLocale() );
        
        return SUCCESS;
    }
}
