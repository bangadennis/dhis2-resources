package no.uio.inf5750.example.model;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class DefaultStudentService
    implements StudentService
{
    private List<Student> students = new ArrayList<Student>();
    
    public void saveStudent( Student student )
    {
        students.add( student );
    }
    
    public void deleteStudent( Student student )
    {
        students.remove( student );
    }
    
    public Collection<Student> getAllStudents()
    {
        return students;
    }
}
